<?php $__env->startSection('title', 'Check Out'); ?>

<?php $__env->startSection('body'); ?>














<div class="checkout-section spad" style="margin-top: 30px;">
    <div class="container mt-16">
        <form action="" method="post" class="checkout-form">
            <input type="number" hidden name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>">
            <input type="text" hidden name="subtotal" value="<?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::subtotal()); ?>">
            <input type="text" hidden name="status" value="0">
            <?php echo csrf_field(); ?>
            <div class="row">
                <?php if(Cart::count() > 0): ?>
                <div class="col-lg-6">

                    <h4>Biiling Details</h4>
                    <div class="row">
                        <div class="col-lg-6">
                            <label for="fir">First Name<span>*</span></label>
                            <input type="text" id="fir" name="first_name" required>
                        </div>
                        <div class="col-lg-6">
                            <label for="last">Last Name<span>*</span></label>
                            <input type="text" id="last" name="last_name" required>
                        </div>
                        <div class="col-lg-12">
                            <label for="cun">Country<span>*</span></label>
                            <input type="text" id="cun" name="country" required>
                        </div>
                        <div class="col-lg-12">
                            <label for="street">Street Address<span>*</span></label>
                            <input type="text" id="street" class="street-first"  name="street_address" required>
                        </div>
                        <div class="col-lg-12">
                            <label for="town">Town / City<span>*</span></label>
                            <input type="text" id="town" name="town_city" required>
                        </div>
                        <div class="col-lg-6">
                            <label for="email">Email Address<span>*</span></label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="col-lg-6">
                            <label for="phone">Phone<span>*</span></label>
                            <input type="number" id="phone" name="phone" required>
                        </div>

                    </div>
                </div>
                <div class="col-lg-6">

                    <div class="place-order">
                        <h4>Your Order</h4>
                        <div class="order-total">
                            <ul class="order-table">
                                <li>Product <span>Total</span></li>

                                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="fw-normal">
                                    <?php echo e($cart->name); ?> x <?php echo e($cart->qty); ?>

                                    <span>$<?php echo e($cart->price * $cart->qty); ?></span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <li class="fw-normal">Subtotal <span>$<?php echo e($subtotal); ?></span></li>
                                <li class="total-price">Total <span>$<?php echo e($total); ?></span></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <div class="payment-check">
                                <div class="pc-item">
                                    <label for="pc-check">
                                        Pay later
                                        <input type="radio" id="pc-check" name="payment_type" value="pay_later" checked>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="pc-item">
                                    <label for="pc-paypal">
                                        Online payment
                                        <input type="radio" id="pc-paypal" name="payment_type" value="online_payment">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                            <div class="order-btn">
                                <button type="submit" class="place-btn">Place Order</button>  <!-- class="site-btn" -->
                            </div>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                    <div class="col-lg-12">
                        <h4>Your cart is empty.</h4>
                    </div>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamPP\DuLieu\bookstore (1)\bookstore\resources\views/front/checkout/index.blade.php ENDPATH**/ ?>