<?php

namespace App\Services\ProductComment;

use App\Repositories\RepositoryInterface;

interface ProductCommentRepositoryInterface extends RepositoryInterface
{

}
