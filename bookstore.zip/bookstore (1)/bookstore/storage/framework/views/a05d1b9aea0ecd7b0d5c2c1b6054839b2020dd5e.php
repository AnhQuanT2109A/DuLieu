<?php $__env->startSection('title', 'List Product'); ?>

<?php $__env->startSection('body'); ?>
	<div class="hero page-inner overlay" style="background-image: url('front/img/hero_bg_1.jpg');">

		<div class="container">
			<div class="row justify-content-center align-items-center">
				<div class="col-lg-9 text-center mt-5">
					<h1 class="heading" data-aos="fade-up">Products</h1>

					<nav aria-label="breadcrumb" data-aos="fade-up" data-aos-delay="200">
						<ol class="breadcrumb text-center justify-content-center">
							<li class="breadcrumb-item "><a href="./">Home</a></li>
							<li class="breadcrumb-item active text-white-50" aria-current="page">Products</li>
						</ol>
					</nav>
				</div>
			</div>
		</div>
	</div>

	<div class="section section-properties">
		<div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="filter-sidebar">
                        <div class="filter-widget">
                            <h4 class="fw-title">Categories</h4>
                            <ul class="filter-catagories">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="shop/<?php echo e($category->name); ?>"><?php echo e($category->name); ?></a></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <form action="">
                            <div class="filter-widget">
                                <h4 class="fw-title">Author</h4>
                                <div class="fw-brand-check">
                                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="bc-item">
                                                <label for="bc-author<?php echo e($author->id); ?>">
                                                    <?php echo e($author->name); ?>

                                                    <input
                                                        type="radio"
                                                        id="bc-author<?php echo e($author->id); ?>"
                                                        value="<?php echo e($author->id); ?>"
                                                        name="author"
                                                        onclick="this.form.submit()"
                                                        <?php echo e(request('author')==$author->id ? 'checked' : ''); ?>

                                                    >
                                                    <span class="checkmark"></span>
                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <div class="filter-widget">
                                <h4 class="fw-title">Price</h4>
                                    <div class="filter-range-wrap">
                                        <div class="range-slider">
                                            <div class="price-input" style="display:flex; gap: 12px;">
                                                <div>
                                                    <label for="first_name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Min Price</label>
                                                    <input name="price_min" min="0" max="100" value="<?php echo e(request('price_min')??0); ?>" type="number" id="first_name" class="price-from bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="0" required>
                                                </div>
                                                <span style="transform: translateY(30px);">_</span>
                                                <div>
                                                    <label for="last_name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Max Price</label>
                                                    <input name="price_max" min="0"  max="100" value="<?php echo e(request('price_max')??100); ?>" type="number" id="last_name" class="price-to bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="100" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="price-range ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content" data-min="33" data-max ="98">
                                            <div class="ui-slider-range ui-corner-all ui-widget-header"></div>
                                            <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                                            <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                                        </div>
                                    </div>
                                    <button class="filter-btn">Filter</button>
                            </div>
                        </form>

                    </div>
                </div>

                <div class="col-lg-9">
                    <div class="row">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                <div class="property-item mb-30">
                                    
                                    <div class="box">
                                        <a href="product/<?php echo e($product->id); ?>" class="img">
                                            <img src="front/img/products/<?php echo e($product->productImages[0]->path); ?>" alt="Image" class="img-fluid-2">
                                        </a>
                                    </div>

                                    <div class="property-content">
                                        <div class="property-price">
                                            <div class="price mb-2"><span>$<?php echo e($product->price); ?></span></div>
                                            <div class="price price-2 mb-2">$<?php echo e($product->discount); ?></div>
                                        </div>

                                        <div>
                                            <span class="city d-block mb-3"><?php echo e($product->name); ?></span>
                                            <span class="d-block mb-2 text-black-50"> <?php echo e($product->author->name); ?> </span>

                                            <div class="btn-pro">
                                                <a href="product/<?php echo e($product->id); ?>" class="btn btn-primary py-2 px-3">See Details</a>
                                                <a href="cart/add/<?php echo e($product->id); ?>" class="btn btn-primary py-2 px-3">Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- .item -->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="row align-items-center py-5">
                            <?php echo $products->links(); ?>

                        </div>
                    </div>
                </div>
            </div>


		</div>
	</div>
    <script>
        let min=document.querySelector('.price-from')
        let max=document.querySelector('.price-to')
        max.min = min.value -''+1;
        min.max = max.value - 1
        min.addEventListener('change',function (){
            max.min = min.value -''+1;
        })
        max.addEventListener('change',function (){
            min.max = max.value-1;
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamPP\DuLieu\bookstore (1)\bookstore\resources\views/front/shop/index.blade.php ENDPATH**/ ?>