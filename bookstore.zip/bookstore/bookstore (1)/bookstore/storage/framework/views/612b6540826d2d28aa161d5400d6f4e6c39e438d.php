

<?php $__env->startSection('title', 'Cart'); ?>

<?php $__env->startSection('body'); ?>

    <div class="hero">


        <div class="hero-slide">
            <div class="img overlay" style="background-image: url('front/img/hero_bg_3.jpg')"></div>
        </div>

        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-9 text-center">
                    <h1 class="heading" data-aos="fade-up">Where there are useful and interesting books</h1>
                    <form action="./product" class="narrow-w form-search d-flex align-items-stretch mb-3" data-aos="fade-up" data-aos-delay="200">
                        <input type="text" class="form-control px-4" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search for your favorite books">
                        <button type="submit" class="btn btn-primary">Search</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<div class="shopping-cart spad">
    <div class="container">
        <div class="row">
            <?php if(Cart::count() > 0): ?>
            <div class="col-lg-12">
                <div class="cart-table">
                    <table>
                        <thead>
                        <tr>
                            <th>Image</th>
                            <th class="p-name">Product Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th><i onclick="confirm('Are you sure?')=== true ? window.location='./cart/destroy' : ''" class="ti-close"></i></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="cart-pic first-row"><img style="height: 150px" src="front/img/products/<?php echo e($cart->options->images[0]->path); ?>"> </td>
                            <td class="card-title first-row">
                                <h5><?php echo e($cart->name); ?></h5>
                            </td>
                            <td class="p-price first-row">$<?php echo e(number_format($cart->price, 2)); ?></td>
                            <td class="qua-col first-row">
                                <div class="quantity">
                                    <div class="pro-qty">
                                        <span class="dec qtybtn"> - </span>
                                            <input type="text" value="<?php echo e($cart->qty); ?>" data-rowid="<?php echo e($cart->rowId); ?>">
                                        <span class="inc qtybtn"> + </span>
                                    </div>
                                </div>
                            </td>
                            <td class="total-price first-row">$<?php echo e(number_format($cart->price * $cart->qty, 2)); ?></td>
                            <td class="close-td first-row">
                                <i onclick="window.location='./cart/delete/<?php echo e($cart->rowId); ?>'" class="ti-close"></i>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="row">
                    <div class="col-lg-4">








                    </div>
                    <div class="col-lg-4 offset-lg-4">
                        <div class="proceed-checkout">
                            <ul>
                                <li class="subtotal">Subtotal<span>$<?php echo e($total); ?></span></li>
                                <li class="cart-total">Total<span>$<?php echo e($subtotal); ?></span></li>
                            </ul>
                            <a href="./checkout" class="proceed-btn">PROCEED TO CHECKOUT</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <div class="col-lg-12">
                    <h4>Your cart is empty.</h4>
                    <div style="margin-bottom: 40px;"></div>
                    <div class="cart-buttons">
                        <a href="./product" style="background-color: #005555; color: #fff" class="primary-btn up-cart">Continue Shopping</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamPP\DuLieu\bookstore\bookstore (1)\bookstore\resources\views/front/shop/cart.blade.php ENDPATH**/ ?>