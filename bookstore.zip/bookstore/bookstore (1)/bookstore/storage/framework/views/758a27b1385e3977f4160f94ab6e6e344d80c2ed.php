<?php if(session('notification')): ?>
    <div class="alert alert-warning" role="alert">
        <?php echo e(session('notification')); ?>

    </div>
<?php endif; ?>
<?php /**PATH D:\xamPP\DuLieu\bookstore\bookstore (1)\bookstore\resources\views/admin/components/notification.blade.php ENDPATH**/ ?>